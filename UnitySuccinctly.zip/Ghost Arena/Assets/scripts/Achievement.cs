﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class Achievement
{
    public string Name;
    public string Description;
    public DateTime? DateUnlocked;
    public Sprite Icon;
       
}
